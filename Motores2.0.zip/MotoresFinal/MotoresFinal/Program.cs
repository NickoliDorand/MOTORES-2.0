﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MotoresFinal
{
    internal class Program
    {
        static double[] valor;
        //-----------------------------------------------------------------------------------------------
        static void inverteTela()
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
        }
        //-----------------------------------------------------------------------------------------------
        static void lancar()
        {
            int motor;
            do
            {
                Console.WriteLine("------------------");
                Console.Write("Insira o número do motor desejado: ");
                motor = int.Parse(Console.ReadLine());
            }
            while (motor < 1 || motor > 15);

            Console.Write("Insira o valor do motor selecionado: ");
            valor[motor - 1] += double.Parse(Console.ReadLine());

            Console.WriteLine("Valor registrado com sucesso!");
            Console.WriteLine("------------------");
        }
        //-----------------------------------------------------------------------------------------------
        static void mostrar()
        {
            int motor;
            double total;

            total = 0;
            for (motor = 0; motor < 15; motor++)
            {
                Console.WriteLine("Motor {0}: R$ {1}", motor + 1, valor[motor]);
                total += valor[motor];
            }
            Console.WriteLine("------------------");
            Console.WriteLine("Total: R$ {0}", total);
        }
        //-----------------------------------------------------------------------------------------------

        static void mmaior()
        {
            int motor;
            double maior = valor[0];
            double pMaior = 0;

            Console.WriteLine("------------------");

            if (valor.Sum() == 0)
            {
                Console.WriteLine("Não houve gasto em nenhum motor!");
            }

            else
            {
                for (motor = 1; motor < 15; motor++)
                {
                    if (maior < valor[motor])
                    {
                        maior = valor[motor];
                        pMaior = motor;
                    }
                }
                Console.WriteLine("O motor de MAIOR valor é o Motor {0} com R${1}", (pMaior + 1), maior);
            }

          Console.WriteLine("------------------");
        }
        //-----------------------------------------------------------------------------------------------
        static void mmenor()
        {
            int motor;
            double menor = double.PositiveInfinity;
            double pMenor = 0;
            
            Console.WriteLine("------------------");

            if (valor.Sum() == 0)
            {
                Console.WriteLine("Não houve gasto em nenhum motor!");
            }
            else
            {
                for (motor = 0; motor < 15; motor++)
                {
                    if(valor[motor] != 0)
                    {
                        if (menor > valor[motor])
                        {
                            menor = valor[motor];
                            pMenor = motor;
                        }
                    }
                }
                Console.WriteLine("O motor de MENOR valor é o Motor {0} com R${1}", (pMenor + 1), menor);
            }
            Console.WriteLine("------------------");
        }
        //-----------------------------------------------------------------------------------------------
        static void Main(string[] args)
        {

            valor = new double[15];
            int op;

            inverteTela();

            do
            {
                Console.WriteLine("0. Sair");
                Console.WriteLine("1. Lançar valor");
                Console.WriteLine("2. Mostrar valores");
                Console.WriteLine("3. Mostrar motor com MAIOR gasto");
                Console.WriteLine("4. Mostrar motor com MENOR gasto");
                Console.Write("Digite a opção desejada: ");
                op = int.Parse(Console.ReadLine());

                switch (op)
                {
                    case 1:
                        {
                            lancar();
                            break;
                        }
                    case 2:
                        {
                            mostrar();
                            break;
                        }
                    case 3:
                        {
                            mmaior();
                            break;
                        }
                    case 4:
                        {
                            mmenor();
                            break;
                        }
                }
            }
            while (op != 0);
            Console.WriteLine("------------------");
            mostrar();
            Console.WriteLine("------------------");
        }
    }
}
